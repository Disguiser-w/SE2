//package businessbl;
//
//import static org.junit.Assert.*;
//
//import java.util.ArrayList;
//
//import org.junit.Before;
//import org.junit.Test;
//
//import businesslogic.businessbl.controller.VehicleManagerController;
//import vo.VehicleVO;
//
//public class VehicleManagerTest {
//
//	private VehicleManagerController controller;
//
////	@Before
////	public void setUp() throws Exception {
////		controller = new VehicleManagerController();
////	}
////
////	@Test
////	public void testGetVehicleInfo() {
////		ArrayList<VehicleVO> vos = controller.getVehicleInfo();
////		String ID = vos.get(0).ID;
////		assertEquals("025-001-112", ID);
////	}
////
////	@Test
////	public void testAddVehicle() {
//////		VehicleVO vo = new VehicleVO(null, null, null, null, null, null);
//////		assertEquals(true, controller.addVehicle(vo));
////	}
////
////	@Test
////	public void testDeleteVehicle() {
//////		VehicleVO vo = new VehicleVO(null, null, null, null, null, null);
//////		assertEquals(true, controller.deleteVehicle(vo));
////	}
////
////	@Test
////	public void testModifyVehicle() {
//////		VehicleVO vo = new VehicleVO(null, null, null, null, null, null);
//////		assertEquals(true, controller.modifyVehicle(vo));
////	}
//}
