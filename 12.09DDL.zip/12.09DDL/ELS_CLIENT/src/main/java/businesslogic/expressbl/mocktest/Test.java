package businesslogic.expressbl.mocktest;

import junit.framework.TestCase;

public class Test extends TestCase {

	public void setUp() {
		
	}
	
	
}
