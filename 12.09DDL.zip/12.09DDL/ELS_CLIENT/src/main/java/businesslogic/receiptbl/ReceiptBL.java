package businesslogic.receiptbl;

import java.util.ArrayList;

import vo.ReceiptVO;
import businesslogicservice.receiptblservice.ReceiptBLService;

public class ReceiptBL implements ReceiptBLService {

	public boolean add(ReceiptVO vo) {
		// TODO 自动生成的方法存根
		return false;
	}

	public boolean modify(String ID) {
		// TODO 自动生成的方法存根
		return false;
	}

	public boolean batch(String[] ID) {
		// TODO 自动生成的方法存根
		return false;
	}

	public boolean update(ReceiptVO vo) {
		// TODO 自动生成的方法存根

		return false;
	}

	public void reply(String userID) {
		// TODO 自动生成的方法存根

	}

	public ArrayList<ReceiptVO> view() {
		// TODO 自动生成的方法存根
		return null;
	}

	public ArrayList<ReceiptVO> refresh() {
		// TODO 自动生成的方法存根
		return null;
	}

	public boolean approve(String ID) {
		// TODO 自动生成的方法存根
		return false;
	}

}
