package init;

import businesslogic.businessbl.controller.BusinessMainController;
import businesslogic.expressbl.controller.ExpressMainController;

public class MainController {
//	public static final int EXPRESS_USING = 0;
//	public static final int BUSINESS_USING = 1;
//	
//	private ExpressMainController expressController;
//	private BusinessMainController businessController;
//	
//	public MainController(int user){
//		if(user==EXPRESS_USING)
//			expressController = new ExpressMainController("kdy-00001");
//	}
}
