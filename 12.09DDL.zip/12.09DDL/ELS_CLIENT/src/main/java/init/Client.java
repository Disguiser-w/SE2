
package init;

import presentation.mainui.MainFrame;

public class Client {
	public static void main(String[] args) {
		
		new MainFrame();
	}
}
