package businesslogicservice.financeblservice;

import java.util.ArrayList;

import vo.BusinessStatementReceiptVO;

public class BusinessstatementReceiptBLService_stub implements BusinessstatementReceiptBLService{

	public BusinessStatementReceiptVO showBSList(String beginTime, String endTime) {
		// TODO Auto-generated method stub
		System.out.println("BSList has been shown successfully!");
		return null;
	}

	public ArrayList<BusinessStatementReceiptVO> showAllBSList() {
		// TODO Auto-generated method stub
		System.out.println("All BSList have been shown successfully!");
		return null;
	}

	public int export(BusinessStatementReceiptVO vo) {
		// TODO Auto-generated method stub
		System.out.println("Export successfully!");
		return 0;
	}

}
