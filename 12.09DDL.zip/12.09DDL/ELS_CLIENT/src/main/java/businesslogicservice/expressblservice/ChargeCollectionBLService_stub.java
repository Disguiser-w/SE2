package businesslogicservice.expressblservice;

import vo.ExpressVO;

public class ChargeCollectionBLService_stub implements ChargeCollectionBLService {

	@Override
	public boolean chargeCollection(String chargeInfo) {
		// TODO Auto-generated method stub
		return false;
	}



}
