package businesslogicservice.expressblservice;

import vo.OrderVO;

public class AddOrderBLService_stub implements AddOrderBLService {

	public boolean addOrder(OrderVO vo) {
		// TODO Auto-generated method stub
		System.out.println("AddOrder successfully!");
		return false;
	}

	public void calculateCost(OrderVO vo) {
		// TODO Auto-generated method stub
		System.out.println("Show OrderVO!");
	}
}
