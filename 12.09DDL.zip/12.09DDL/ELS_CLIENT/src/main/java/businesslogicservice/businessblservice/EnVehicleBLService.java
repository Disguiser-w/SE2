package businesslogicservice.businessblservice;

import java.util.ArrayList;

public interface EnVehicleBLService {

	public ArrayList<String> autoTruckLoading();

}
