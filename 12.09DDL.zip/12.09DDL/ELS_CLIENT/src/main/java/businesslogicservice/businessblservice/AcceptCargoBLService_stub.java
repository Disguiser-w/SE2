package businesslogicservice.businessblservice;

import java.util.ArrayList;

import vo.OrderAcceptReceiptVO;

public class AcceptCargoBLService_stub implements  AcceptCargoBLService {



	@Override
	public boolean acceptCargo(String organizationID, String vehicleID, ArrayList<String> orderIDs) {
		// TODO Auto-generated method stub
		return false;
	}

}
