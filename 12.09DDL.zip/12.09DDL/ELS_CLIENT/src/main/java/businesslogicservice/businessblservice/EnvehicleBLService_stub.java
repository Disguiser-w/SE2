package businesslogicservice.businessblservice;

import java.util.ArrayList;

import vo.OrderVO;
import vo.VehicleVO;

public class EnvehicleBLService_stub implements EnVehicleBLService{

	@Override
	public ArrayList<String> autoTruckLoading() {
		// TODO Auto-generated method stub
		return null;
	}


	

	

}
