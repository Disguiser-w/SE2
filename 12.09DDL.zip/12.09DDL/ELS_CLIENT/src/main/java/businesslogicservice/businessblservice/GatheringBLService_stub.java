package businesslogicservice.businessblservice;

import java.util.ArrayList;

import vo.ExpressVO;
import vo.GatheringReceiptVO;

public class GatheringBLService_stub implements GatheringBLService{

	@Override
	public ArrayList<String> getChargeInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double gathering() {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
