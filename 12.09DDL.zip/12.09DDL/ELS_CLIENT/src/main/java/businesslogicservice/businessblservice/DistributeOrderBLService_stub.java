package businesslogicservice.businessblservice;

import java.rmi.RemoteException;
import java.util.ArrayList;

import vo.ExpressVO;
import vo.OrderVO;

public class DistributeOrderBLService_stub implements DistributeOrderBLService{

	@Override
	public ArrayList<String> distributeOrder() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
