package businesslogicservice.manageblservice;

import java.util.ArrayList;

import vo.CityDistanceVO;

public class CityDistanceBLService_stub implements CityDistanceBLService{
	
	public int addCityDistance(CityDistanceVO citydistancevo) {
		// TODO 自动生成的方法存根
		System.out.println("Add city distance succeed!");
		return 0;
	}

    public int deleteCityDistance(CityDistanceVO citydistancevo) {
        // TODO 自动生成的方法存根
        System.out.println("Delete city distance succeed!");
        return 0;
    }
		
    public int modifyCityDistance(CityDistanceVO citydistancevo) {
        // TODO 自动生成的方法存根
        System.out.println("Modify city distance succeed!");
        return 0;
    }
    
    public ArrayList<CityDistanceVO> findCityDistanceBySingle(String city) {
        // TODO 自动生成的方法存根
        System.out.println("Find city distance by single succeed!");
        return null;
    }
    
    public CityDistanceVO findCityDistanceByBoth(String cityA, String cityB) {
        // TODO 自动生成的方法存根
        System.out.println("Find city distance by both succeed!");
        return null;
    }

    public ArrayList<CityDistanceVO> showAllCityDistances(){
    	// TODO 自动生成的方法存根
        System.out.println("Show all city distance succeed!");
        return null;
    }
    
}
