package businesslogicservice.manageblservice;

import java.util.ArrayList;

import type.ProfessionType;
import vo.BasicSalaryVO;

public class BasicSalaryBLService_stub implements BasicSalaryBLService {

	public int addBasicSalary(BasicSalaryVO basicsalaryvo) {
		// TODO 自动生成的方法存根
		System.out.println("Add basic salary succeed!");
		return 0;
	}

    public int deleteBasicSalary(BasicSalaryVO basicsalaryvo) {
        // TODO 自动生成的方法存根
        System.out.println("Delete basic salary succeed!");
        return 0;
    }
		
    public int modifyBasicSalary(BasicSalaryVO basicsalaryvo) {
        // TODO 自动生成的方法存根
        System.out.println("Modify basic salary succeed!");
        return 0;
    }
    
    public double findBasicSalary(ProfessionType profession) {
        // TODO 自动生成的方法存根
        System.out.println("Find basic salary succeed!");
        return 0;
    }
	
    public ArrayList<BasicSalaryVO> showAllBasicSalarys(){
    	// TODO 自动生成的方法存根
        System.out.println("Show all basic salary succeed!");
        return null;
    }
    
}
