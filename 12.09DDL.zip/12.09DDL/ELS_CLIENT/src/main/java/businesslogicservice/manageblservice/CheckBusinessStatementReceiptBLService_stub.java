package businesslogicservice.manageblservice;

import vo.BusinessStatementReceiptVO;

public class CheckBusinessStatementReceiptBLService_stub implements CheckBusinessStatementReceiptBLService{

	public BusinessStatementReceiptVO showBSList(String beginTime, String endTime) {
		// TODO Auto-generated method stub
		System.out.println("BSList has been shown successfully!");
		return null;
	}

	public int export(BusinessStatementReceiptVO vo) {
		// TODO Auto-generated method stub
		System.out.println("Export successfully!");
		return 0;
	}

}
