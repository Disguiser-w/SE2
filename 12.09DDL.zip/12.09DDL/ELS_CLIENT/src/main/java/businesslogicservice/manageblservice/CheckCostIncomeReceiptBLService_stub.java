package businesslogicservice.manageblservice;

import vo.CostIncomeReceiptVO;

public class CheckCostIncomeReceiptBLService_stub implements CheckCostIncomeReceiptBLService{

	public CostIncomeReceiptVO getCostIncomeList(String s) {
		// TODO Auto-generated method stub
		System.out.println("Get CIL successfully!");
		return null;
	}

}
