package businesslogicservice.manageblservice;

import java.util.ArrayList;

import type.ProfessionType;
import vo.PerWageVO;

public class PerWageBLService_stub implements PerWageBLService {

	public int addPerWage(PerWageVO perwagevo) {
		// TODO 自动生成的方法存根
		System.out.println("Add perwage succeed!");
		return 0;
	}

    public int deletePerWage(PerWageVO perwagevo) {
        // TODO 自动生成的方法存根
        System.out.println("Delete perwage succeed!");
        return 0;
    }
		
    public int modifyPerWage(PerWageVO perwagevo) {
        // TODO 自动生成的方法存根
        System.out.println("Modify perwage succeed!");
        return 0;
    }
    
    public double findPerWage(ProfessionType profession) {
        // TODO 自动生成的方法存根
        System.out.println("Find perwage succeed!");
        return 0;
    }
    
    public ArrayList<PerWageVO> showAllPerWages(){
    	// TODO 自动生成的方法存根
        System.out.println("Show all perwage succeed!");
        return null;
    }
    
}
