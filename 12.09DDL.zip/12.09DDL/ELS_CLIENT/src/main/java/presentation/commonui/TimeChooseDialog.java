package presentation.commonui;

import javax.swing.JDialog;

public class TimeChooseDialog extends JDialog{
	
}
