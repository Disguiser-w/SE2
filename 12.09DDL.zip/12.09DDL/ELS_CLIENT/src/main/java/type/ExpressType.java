package type;

public enum ExpressType {
	ECONOMIC, STANDARD, FAST;
	// 经济型    标准型      特快型
}
