package type;

public enum SalaryPlanType {
	courierSalaryPlan, driverSalaryPlan, basicStaffSalaryPlan;
//  快递员（基础月薪+计次提成）司机（计次）	 其他（基础月薪）
}
