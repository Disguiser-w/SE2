package type;

public enum AuthorityType {
	lowest,administrator,commonFianacialStaff,highest;
//  最低权限, 管理员权限 , 普通财务人员权限,     最高权限（最高财务人员和总经理）
}
