package type;

public enum OperationState {
    SUCCEED_OPERATION,FAIL_OPERATION,WAIT_OPERATION
}
