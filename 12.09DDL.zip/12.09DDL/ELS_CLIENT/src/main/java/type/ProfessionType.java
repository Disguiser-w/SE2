package type;

public enum ProfessionType {
	courier, driver, stockman, businessHallCounterman, intermediateCenterCounterman, administrator, financialStaff, manager;
//	快递员	 司机	  仓库管理员 		 营业厅业务员				 中转中心业务员，                    管理员			财务人员           	 总经理		
}