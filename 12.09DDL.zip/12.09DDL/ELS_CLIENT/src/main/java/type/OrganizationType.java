package type;

public enum OrganizationType {
	businessHall, intermediateCenter;
//	营业厅                 中转中心
}
