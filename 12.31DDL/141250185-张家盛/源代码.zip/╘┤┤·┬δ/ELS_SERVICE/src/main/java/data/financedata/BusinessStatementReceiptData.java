package data.financedata;

/**
 * 因为不需要存储：所以感觉这个类根本就不需要了
 * */
public class BusinessStatementReceiptData {

}
