package businesslogicservice.businessblservice;

import java.util.ArrayList;

public class GatheringBLService_stub implements GatheringBLService{



	@Override
	public double gathering() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<String[]> getChargeInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
