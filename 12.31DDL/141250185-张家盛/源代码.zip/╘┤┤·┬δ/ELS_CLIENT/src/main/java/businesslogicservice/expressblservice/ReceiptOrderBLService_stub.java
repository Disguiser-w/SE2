package businesslogicservice.expressblservice;

import vo.OrderVO;

public class ReceiptOrderBLService_stub implements ReceiptOrderBLService {

	public boolean receiptOrder(OrderVO vo) {
		// TODO Auto-generated method stub
		System.out.println("ReceiptOrder successfully!");
		return false;
	}

	@Override
	public OrderVO getOrderInfo(String orderID) {
		// TODO Auto-generated method stub
		return null;
	}

}
