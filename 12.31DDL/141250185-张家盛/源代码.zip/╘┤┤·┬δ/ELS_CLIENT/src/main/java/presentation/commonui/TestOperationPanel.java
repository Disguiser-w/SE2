package presentation.commonui;

public class TestOperationPanel extends OperationPanel{
	
}
