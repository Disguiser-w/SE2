package type;

public enum Sexuality {
	MALE,FEMALE
}