package businesslogicservice.businessblservice;

import java.util.ArrayList;

public class AcceptCargoBLService_stub implements AcceptCargoBLService {

	@Override
	public boolean acceptCargo(String vehicleID, ArrayList<String> orderIDs) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean orderExist(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean vehicleExist(String vehicleID) {
		// TODO Auto-generated method stub
		return false;
	}

}
