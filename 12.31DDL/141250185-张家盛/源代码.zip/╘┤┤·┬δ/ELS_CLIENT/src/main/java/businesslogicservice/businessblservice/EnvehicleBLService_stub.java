package businesslogicservice.businessblservice;

import java.util.ArrayList;

public class EnvehicleBLService_stub implements EnVehicleBLService{

	@Override
	public ArrayList<String[]> autoTruckLoading() {
		// TODO Auto-generated method stub
		return null;
	}


	

	

}
