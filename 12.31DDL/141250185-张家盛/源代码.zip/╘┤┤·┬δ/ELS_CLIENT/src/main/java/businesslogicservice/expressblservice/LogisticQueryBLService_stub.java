package businesslogicservice.expressblservice;

import java.util.ArrayList;

import vo.OrderVO;

public class LogisticQueryBLService_stub implements LogisticQueryBLService{





	@Override
	public ArrayList<OrderVO> query() {
		// TODO Auto-generated method stub
		return null;
	}

}
