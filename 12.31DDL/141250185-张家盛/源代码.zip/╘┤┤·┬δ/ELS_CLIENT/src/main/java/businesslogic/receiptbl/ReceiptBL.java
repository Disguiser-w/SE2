package businesslogic.receiptbl;

import businesslogicservice.receiptblservice.ReceiptBLService;

public class ReceiptBL implements ReceiptBLService {

	public void see(Object receipt){
		// TODO 自动生成的方法存根
	}

	public int approve(String ID) {
		// TODO 自动生成的方法存根
		return 0;
	}

}
