package vo;

public class CityDistanceVO {
	
	public String cityA;
	public String cityB;
	public double distance;
	
	public CityDistanceVO(String cityA, String cityB, double distance){
		this.cityA = cityA;
		this.cityB = cityB;
		this.distance = distance;
	}
	
}
