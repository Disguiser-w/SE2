package businesslogic.receiptbl;

import vo.ReceiptVO;

public class MockReceipt extends ReceiptBL {
    public boolean update(ReceiptVO vo){
    	return true;
    }
}
