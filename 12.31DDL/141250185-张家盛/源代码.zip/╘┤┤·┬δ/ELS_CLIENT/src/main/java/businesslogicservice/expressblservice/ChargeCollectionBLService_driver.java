package businesslogicservice.expressblservice;

public class ChargeCollectionBLService_driver {
	public void drive(ChargeCollectionBLService chargeCollecitonBLService) {
//		chargeCollecitonBLService.getChargeInfo();
//		chargeCollecitonBLService.chargeCollection(null);
	}

	public void main(String[] args) {
		(new ChargeCollectionBLService_driver()).drive(new ChargeCollectionBLService_stub());
	}
}
