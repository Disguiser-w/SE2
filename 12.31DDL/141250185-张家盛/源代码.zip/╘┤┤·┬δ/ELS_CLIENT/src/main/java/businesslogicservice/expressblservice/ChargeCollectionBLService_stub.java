package businesslogicservice.expressblservice;

public class ChargeCollectionBLService_stub implements ChargeCollectionBLService {

	@Override
	public boolean chargeCollection() {
		// TODO Auto-generated method stub
		return false;
	}





}
