package businesslogic.intermediatebl;

import java.util.ArrayList;

import businesslogicservice.intermediateblservice.envehicleblservice.AllocateWaitingOrderBLService;
import type.OrderState;
import vo.OrderVO;
import vo.TransferingReceiptVO;

public class AllocateWaitingOrderBL implements AllocateWaitingOrderBLService {
	private ArrayList<OrderVO> waitingOrderList = new ArrayList<OrderVO>();
	private TransferingReceiptVO transferingReceipt;

	public AllocateWaitingOrderBL(TransferingReceiptVO transferingReceipt) {
		this.transferingReceipt = transferingReceipt;
	}

	public ArrayList<OrderVO> updateWaitingList() {
		// TODO 自动生成的方法存根
		for (OrderVO order : transferingReceipt.orderList) {
			if (order.order_state == OrderState.TRANSFERING)
				waitingOrderList.add(order);
		}
		return waitingOrderList;
	}

	public OrderVO showOrder(String orderID) throws Exception {
		// TODO 自动生成的方法存根
		for (OrderVO order : transferingReceipt.orderList) {
			if (order.ID == orderID)
				return order;
		}

		throw new Exception("未找到该ID的订单！");
	}

}
