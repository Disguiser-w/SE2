package dataservice.expressdataservice;

public class ExpressDataService_driver {
//	public void drive(ExpressDataService expressDataService) {
//	expressDataService.getBaseCost();
//
//	expressDataService.chargeCollection(new ExpressPO());
//
//	expressDataService.getExpressInfos();
//}
//
//public void main(String[] args){
//	(new ExpressDataService_driver()).drive(new ExpressDataService_stub());
//}
}
