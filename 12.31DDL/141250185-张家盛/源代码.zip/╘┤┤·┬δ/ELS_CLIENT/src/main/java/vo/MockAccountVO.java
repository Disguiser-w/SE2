
package vo;

public class MockAccountVO extends AccountVO{
	public MockAccountVO(String name, double money) {
		super(name, money);
		// TODO Auto-generated constructor stub
	}
	double money;
	String name;
	
//	public MockAccountVO(String n,double m){
//		name=n;
//		money=m;
//	}
//	
//	public String getName(){
//		return name;
//	}
//	
//	public double getMoney(){
//		return money;
//	}

}