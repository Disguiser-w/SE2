package presentation.special_ui;

public class CloseLabel {

}
