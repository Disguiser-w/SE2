//package businessbl;
//
//import static org.junit.Assert.assertEquals;
//
//import java.util.ArrayList;
//
//import org.junit.Before;
//import org.junit.Test;
//
//import businesslogic.businessbl.controller.DriverManagerController;
//import vo.DriverVO;
//
//public class DriverManagerTest {
//	private DriverManagerController controller;
//
////	@Before
////	public void setUp() throws Exception {
////		controller = new DriverManagerController();
////	}
////
////	@Test
////	public void testGetDriverInfo() {
////		ArrayList<DriverVO> vos = controller.getDriverInfo();
////		String ID = vos.get(0).ID;
////		assertEquals("025-000-111", ID);
////	}
////
////	@Test
////	public void testAddDriver() {
//////		DriverVO vo = new DriverVO(null, null, null, null, null, null, null, null);
//////		assertEquals(true, controller.addDriver(vo));
////	}
////
////	@Test
////	public void testDeleteDriver() {
//////		DriverVO vo = new DriverVO(null, null, null, null, null, null, null, null);
//////		assertEquals(true, controller.deleteDriver(vo));
////	}
////
////	@Test
////	public void testModifyDriver() {
//////		DriverVO vo = new DriverVO(null, null, null, null, null, null, null, null);
//////		assertEquals(true, controller.modifyDriver(vo));
////	}
//
//}
