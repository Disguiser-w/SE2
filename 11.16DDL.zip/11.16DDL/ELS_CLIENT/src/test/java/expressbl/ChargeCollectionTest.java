package expressbl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import businesslogic.expressbl.controller.ChargeCollectionController;
import vo.ExpressVO;

public class ChargeCollectionTest {
	public ChargeCollectionController controller;

	@Before
	public void setUp() throws Exception {
		controller = new ChargeCollectionController();
	}

	@Test
	public void testGetChargeInfo() {
		assertEquals(10, (int) (controller.getChargeInfo().chargeCollection.get(0) + 0.0));
	}

	@Test
	public void testChargeCollection() {
		ExpressVO vo = new ExpressVO("狗剩", "YYT-00001", "100", null, null, null, null, null);
		assertEquals(true, controller.chargeCollection(vo));
	}

}
