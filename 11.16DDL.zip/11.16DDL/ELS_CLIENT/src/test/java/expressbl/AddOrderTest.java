package expressbl;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import businesslogic.expressbl.controller.AddOrderController;
import vo.OrderVO;

/**
 * 与本模块交互的其他模块的类ExpressVO和OrderVO由同一人完成，所以不再为其编写mock，而是直接使用
 * */
public class AddOrderTest {

	public AddOrderController controller;

	@Before
	public void setUp() throws Exception {
		controller = new AddOrderController();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddOrder() {
		assertEquals(controller.addOrder(null), true);
	}

	@Test
	public void testCalculateCost() {
//		OrderVO vo = new OrderVO();
//		assertEquals(10, (int)controller.calculateCost(vo).freight);
	}

}
