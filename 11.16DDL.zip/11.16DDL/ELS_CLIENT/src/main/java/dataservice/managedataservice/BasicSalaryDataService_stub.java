package dataservice.managedataservice;

import po.BasicSalaryPO;
import type.ProfessionType;

import java.rmi.RemoteException;

public class BasicSalaryDataService_stub {
	
	public int addBasicSalary(BasicSalaryPO basicsalarypo) throws RemoteException {
		// TODO 自动生成的方法存根
		System.out.println("Add basic salary succeed!");
		return 0;
	}

    public int deleteBasicSalary(BasicSalaryPO basicsalarypo) throws RemoteException {
        // TODO 自动生成的方法存根
        System.out.println("Delete basic salary succeed!");
        return 0;
    }
		
    public int modifyBasicSalary(BasicSalaryPO basicsalarypo) throws RemoteException {
        // TODO 自动生成的方法存根
        System.out.println("Modify basic salary succeed!");
        return 0;
    }
    
    public double findBasicSalary(ProfessionType courier) throws RemoteException {
        // TODO 自动生成的方法存根
        System.out.println("Find basic salary succeed!");
        return 0;
    }
	
}
