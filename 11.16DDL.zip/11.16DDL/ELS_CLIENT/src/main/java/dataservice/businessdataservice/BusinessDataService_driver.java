package dataservice.businessdataservice;

import po.DriverPO;
import po.EnVehicleReceiptPO;
import po.VehiclePO;

public class BusinessDataService_driver {
	public void drive(BusinessDataService businessDataService) {
		businessDataService.getVehicleInfos();
		businessDataService.addVehicle(new VehiclePO());
		businessDataService.deleteVehicle(new VehiclePO());
		businessDataService.modifyVehicle(new VehiclePO());
		businessDataService.getDriverInfos(new String());
		businessDataService.addDriver(new DriverPO());
		businessDataService.deleteDriver(new DriverPO());
		businessDataService.modifyDriver(new DriverPO());
		businessDataService.getTransferOrders();
		businessDataService.getFreeVehicles();
		businessDataService.addEnVehicleReceiptPO(new EnVehicleReceiptPO());
	}

	public void main(String[] args) {
		(new BusinessDataService_driver()).drive(new BusinessDataService_stub());
	}
}
