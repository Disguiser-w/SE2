package dataservice.receiptdataservice;

import java.util.ArrayList;

import po.ReceiptPO;

public class ReceiptDataService_stub implements ReceiptDataService {

	public boolean add(ReceiptPO po) {
		// TODO 自动生成的方法存根
		System.out.println("add successfully!");
		return true;
	}

	public ReceiptPO find(String ID) {
		// TODO 自动生成的方法存根
		System.out.println("find successfully!");
		return null;
	}

	public boolean modify(ReceiptPO po) {
		// TODO 自动生成的方法存根
		System.out.println("modify successfully!");
		return true;
	}

	public ArrayList<ReceiptPO> get() {
		// TODO 自动生成的方法存根
		System.out.println("get successfully!");
		return null;
	}

	public void init() {
		// TODO 自动生成的方法存根
		System.out.println("init successfully!");
	}

}
