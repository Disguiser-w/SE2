package dataservice.intermediatedataservice.TranferingDataService;

import po.TransferingReceiptPO;

public class TransferingDataService_stub implements TransferingDataService {

	public TransferingReceiptPO getTransferingReceipt() {
		// TODO 自动生成的方法存根
		System.out.println("get successfully!");
		return null;
	}

	public boolean addOrder(String ID) {
		// TODO 自动生成的方法存根
		System.out.println("add successfully!");
		return false;
	}

	public boolean deleteOrder(String ID) {
		// TODO 自动生成的方法存根
		System.out.println("delete successfully!");
		return false;
	}

	public boolean modifyOrder(String ID) {
		// TODO 自动生成的方法存根
		System.out.println("modify successfully!");
		return false;
	}


	public void updateTransferingReceipt(TransferingReceiptPO po) {
		// TODO Auto-generated method stub
		
	}
    
}
