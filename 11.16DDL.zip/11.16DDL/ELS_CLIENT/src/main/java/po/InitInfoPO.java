package po;

import java.util.ArrayList;

public class InitInfoPO {
	    //机构信息
	   //人员信息
		//车辆信息
		//库存信息
		//账户信息
		ArrayList<AccountPO>  accout;
		public InitInfoPO(){
		}
		public ArrayList<AccountPO> getAccount(){
			return accout;
		}
		}


