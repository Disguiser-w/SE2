package po;

import java.io.Serializable;

public class GoodsPO implements Serializable{
	
	private static final long serialVersionUID = 2L;
	
}
