package presentation.financeui;

public class InitialStockInfoTable_new {

}
