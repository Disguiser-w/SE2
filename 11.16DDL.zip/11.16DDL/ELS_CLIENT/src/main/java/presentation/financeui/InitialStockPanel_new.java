package presentation.financeui;

public class InitialStockPanel_new {

}
