package type;

public enum SalaryPlanType {
	courierSalaryPlan, driverSalaryPlan, countermanSalaryPlan, financialStaffSalaryPlan, stockmanSalaryPlan, managerSalaryPlan, administratorSalaryPlan;
//  快递员（基础月薪+计次提成）司机（计次）	 业务员（基础月薪）		 财务人员（基础月薪）仓库管理员（基础月薪）  总经理（基础月薪）	管理员（基础月薪）	
}
