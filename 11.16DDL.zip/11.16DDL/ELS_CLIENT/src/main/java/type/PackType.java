package type;

public enum PackType {
	CARTONS, WOODCASE, COURIERBAGS
}
