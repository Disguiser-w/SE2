package businesslogicservice.businessblservice;

import vo.OrderAcceptReceiptVO;

public class AcceptCargoBLService_stub implements  AcceptCargoBLService {

	public boolean acceptCargo(OrderAcceptReceiptVO vo) {
		// TODO Auto-generated method stub
		System.out.println("AcceptCargo successfully!");
		return false;
	}

}
