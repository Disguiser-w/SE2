package businesslogicservice.businessblservice;

import java.util.ArrayList;

import vo.OrderVO;
import vo.VehicleVO;

public class EnvehicleBLService_stub implements EnVehicleBLService{

	public String autoTruckLoading() {
		// TODO Auto-generated method stub
		System.out.println("AutoTruckLoading successfully!");
		return null;
	}

	public ArrayList<VehicleVO> getFreeVehicles() {
		// TODO Auto-generated method stub
		System.out.println("Show VehicleVOs!");
		return null;
	}

	public ArrayList<OrderVO> getTransferOrders() {
		// TODO Auto-generated method stub
		System.out.println("Show OrderVOs!");
		return null;
	}

}
