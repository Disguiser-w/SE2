package businesslogicservice.expressblservice;

import vo.OrderVO;

public class ReceiptOrderBLService_stub implements ReceiptOrderBLService{

	public OrderVO getOrderInfo(long orderNum) {
		// TODO Auto-generated method stub
		System.out.println("Show OrderVo！");
		return null;
	}

	public boolean receiptOrder(OrderVO vo) {
		// TODO Auto-generated method stub
		System.out.println("ReceiptOrder successfully!");
		return false;
	}

}
