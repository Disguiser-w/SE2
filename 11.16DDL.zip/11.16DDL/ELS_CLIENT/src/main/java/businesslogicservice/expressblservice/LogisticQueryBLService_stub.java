package businesslogicservice.expressblservice;

import vo.OrderVO;

public class LogisticQueryBLService_stub implements LogisticQueryBLService{

	public OrderVO query(long orderNum) {
		// TODO Auto-generated method stub
		System.out.println("Query successfully!");
		return null;
	}

}
