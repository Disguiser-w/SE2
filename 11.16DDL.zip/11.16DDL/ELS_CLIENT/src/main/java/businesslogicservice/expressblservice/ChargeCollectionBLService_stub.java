package businesslogicservice.expressblservice;

import vo.ExpressVO;

public class ChargeCollectionBLService_stub implements ChargeCollectionBLService {

	public ExpressVO getChargeInfo() {
		// TODO Auto-generated method stub
		System.out.println("Show ExpressVo!");
		return null;
	}

	public boolean chargeCollection(ExpressVO vo) {
		// TODO Auto-generated method stub
		System.out.println("ChargeCollection successfully!");
		return false;
	}

}
