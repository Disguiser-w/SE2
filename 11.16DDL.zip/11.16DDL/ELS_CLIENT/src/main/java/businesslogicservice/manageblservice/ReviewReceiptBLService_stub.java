package businesslogicservice.manageblservice;

public class ReviewReceiptBLService_stub implements ReviewReceiptBLService{
	public int reviewReceipt(String receiptID){
		System.out.println("Review receipt succeed");
		return 0;
	}
}
