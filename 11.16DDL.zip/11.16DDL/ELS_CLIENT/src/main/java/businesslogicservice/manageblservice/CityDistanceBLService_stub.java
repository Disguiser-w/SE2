package businesslogicservice.manageblservice;

import vo.CityDistanceVO;

public class CityDistanceBLService_stub implements CityDistanceBLService{
	
	public int addCityDistance(CityDistanceVO citydistancevo) {
		// TODO 自动生成的方法存根
		System.out.println("Add city distance succeed!");
		return 0;
	}

    public int deleteCityDistance(CityDistanceVO citydistancevo) {
        // TODO 自动生成的方法存根
        System.out.println("Delete city distance succeed!");
        return 0;
    }
		
    public int modifyCityDistance(CityDistanceVO citydistancevo) {
        // TODO 自动生成的方法存根
        System.out.println("Modify city distance succeed!");
        return 0;
    }
    
    public double findCityDistance(String cityA, String cityB) {
        // TODO 自动生成的方法存根
        System.out.println("Find city distance succeed!");
        return 0;
    }

}
