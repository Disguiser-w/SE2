package businesslogicservice.manageblservice;

public interface ReviewReceiptBLService {
	public int reviewReceipt(String receiptID);
}
