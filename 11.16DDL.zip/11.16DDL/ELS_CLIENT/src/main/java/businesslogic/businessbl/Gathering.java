package businesslogic.businessbl;

import java.util.ArrayList;

import businesslogicservice.businessblservice.GatheringBLService;
import dataservice.businessdataservice.BusinessDataService;
import vo.ExpressVO;
import vo.GatheringReceiptVO;

public class Gathering{
	private BusinessDataService businessData;
	
	public Gathering(){
		
	}
	public ArrayList<ExpressVO> getChargeInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	public double gathering(GatheringReceiptVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

}
