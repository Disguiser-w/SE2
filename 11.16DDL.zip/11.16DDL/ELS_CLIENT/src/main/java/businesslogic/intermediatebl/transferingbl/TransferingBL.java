package businesslogic.intermediatebl.transferingbl;

import vo.TransferingReceiptVO;
import businesslogicservice.intermediateblservice.transferingblservice.TransferingBLService;

public class TransferingBL implements TransferingBLService{

	public TransferingReceiptVO showTransferingReceipt() {
		// TODO 自动生成的方法存根
		return null;
	}

	public boolean addOrder(String ID) {
		// TODO 自动生成的方法存根
		return false;
	}

	public boolean deleteOrder(String ID) {
		// TODO 自动生成的方法存根
		return false;
	}

	public boolean modifyOrder(String ID) {
		// TODO 自动生成的方法存根
		return false;
	}

	public TransferingReceiptVO updateTransferingReceipt(TransferingReceiptVO vo) {
		// TODO 自动生成的方法存根
		return null;
	}

}
