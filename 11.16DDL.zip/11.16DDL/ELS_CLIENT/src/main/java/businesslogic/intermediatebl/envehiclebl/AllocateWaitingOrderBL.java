package businesslogic.intermediatebl.envehiclebl;

import java.util.ArrayList;

import vo.OrderVO;
import vo.TransferingReceiptVO;
import businesslogicservice.intermediateblservice.envehicleblservice.AllocateWaitingOrderBLService;

public class AllocateWaitingOrderBL implements AllocateWaitingOrderBLService {

	public ArrayList<OrderVO> updateWaitingList(TransferingReceiptVO vo) {
		// TODO 自动生成的方法存根
		return null;
	}

	public OrderVO showOrder(String orderID) {
		// TODO 自动生成的方法存根
		return null;
	}

}
