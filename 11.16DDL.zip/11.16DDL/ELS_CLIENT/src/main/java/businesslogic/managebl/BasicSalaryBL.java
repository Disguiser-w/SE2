package businesslogic.managebl;

public class BasicSalaryBL {
	
}
