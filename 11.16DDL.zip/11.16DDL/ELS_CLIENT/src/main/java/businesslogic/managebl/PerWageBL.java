package businesslogic.managebl;

public class PerWageBL {
	
}
