package businesslogic.managebl;

public class CostIncomeReceiptBL {

}
