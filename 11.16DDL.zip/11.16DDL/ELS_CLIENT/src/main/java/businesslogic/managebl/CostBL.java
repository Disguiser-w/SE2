package businesslogic.managebl;

public class CostBL {
	
}
