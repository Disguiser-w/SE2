package businesslogic.managebl;

public class ReviewReceiptBL {

}
