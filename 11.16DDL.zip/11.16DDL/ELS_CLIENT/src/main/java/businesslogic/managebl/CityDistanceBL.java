package businesslogic.managebl;

public class CityDistanceBL {
	
}
