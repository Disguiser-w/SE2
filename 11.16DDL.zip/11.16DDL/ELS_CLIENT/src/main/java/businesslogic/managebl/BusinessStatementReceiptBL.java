package businesslogic.managebl;

public class BusinessStatementReceiptBL {

}
