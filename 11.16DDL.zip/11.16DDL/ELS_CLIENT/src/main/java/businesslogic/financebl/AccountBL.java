package businesslogic.financebl;

import java.util.ArrayList;

import businesslogicservice.financeblservice.AccountBLService;
import vo.AccountVO;


public class AccountBL implements AccountBLService{
	double money;
	String name;

	public int addAccount(AccountVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteAccount(AccountVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int modifyAccount(AccountVO vo, String name) {
		// TODO Auto-generated method stub
		return 0;
	}

	public AccountVO findbyName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<AccountVO> findByKeyword(String s) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<AccountVO> showAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public double getMoney(AccountVO vo){
		return vo.getMoney();		
	}
	
	public String getName(AccountVO vo){
		return vo.getName();
	}

}
