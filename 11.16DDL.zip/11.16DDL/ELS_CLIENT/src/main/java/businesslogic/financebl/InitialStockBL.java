package businesslogic.financebl;

public class InitialStockBL {

}
