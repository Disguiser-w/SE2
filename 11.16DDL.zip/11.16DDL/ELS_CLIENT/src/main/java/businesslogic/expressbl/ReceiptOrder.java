package businesslogic.expressbl;

import businesslogicservice.expressblservice.ReceiptOrderBLService;
import dataservice.expressdataservice.ExpressDataService;
import vo.OrderVO;

public class ReceiptOrder {
	private ExpressDataService expressData;

	public ReceiptOrder() {

	}

	public OrderVO getOrderInfo(long orderNum) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean receiptOrder(OrderVO vo) {
		// TODO Auto-generated method stub
		return true;
	}

}
