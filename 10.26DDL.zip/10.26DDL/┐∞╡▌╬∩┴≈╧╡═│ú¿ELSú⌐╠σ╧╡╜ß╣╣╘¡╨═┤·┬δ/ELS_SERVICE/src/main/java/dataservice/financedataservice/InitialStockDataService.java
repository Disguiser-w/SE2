package dataservice.financedataservice;

public class InitialStockDataService {

}
