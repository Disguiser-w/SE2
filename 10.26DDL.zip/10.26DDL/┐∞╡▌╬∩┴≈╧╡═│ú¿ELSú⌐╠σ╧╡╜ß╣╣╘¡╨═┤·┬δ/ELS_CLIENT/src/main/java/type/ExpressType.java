package type;

public enum ExpressType {
	economical, standard, very_fast;
//	经济型             标准型        特快型
}
