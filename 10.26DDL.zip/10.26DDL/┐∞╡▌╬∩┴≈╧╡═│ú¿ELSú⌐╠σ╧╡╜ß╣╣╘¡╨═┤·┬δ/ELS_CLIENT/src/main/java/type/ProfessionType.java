package type;

public enum ProfessionType {
	courier, driver, counterman, financialStaff, stockman, manager, administrator;
//	快递员	 司机	 业务员		 财务人员		 仓库管理员  总经理	管理员	
}
