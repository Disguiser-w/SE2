package businesslogicservice.businessblservice;

import java.util.ArrayList;

import vo.ExpressVO;
import vo.OrderVO;

public class DistributeOrderBLService_stub implements DistributeOrderBLService{

	public String distributeOrder() {
		// TODO Auto-generated method stub
		System.out.println("Distribute successfully!");
		return null;
	}

	public ArrayList<ExpressVO> getExpressInfos() {
		// TODO Auto-generated method stub
		System.out.println("Show ExpressVOs!");
		return null;
	}

	public ArrayList<OrderVO> getSendOrder() {
		// TODO Auto-generated method stub
		System.out.println("Show OrderVOs!");
		return null;
	}

}
