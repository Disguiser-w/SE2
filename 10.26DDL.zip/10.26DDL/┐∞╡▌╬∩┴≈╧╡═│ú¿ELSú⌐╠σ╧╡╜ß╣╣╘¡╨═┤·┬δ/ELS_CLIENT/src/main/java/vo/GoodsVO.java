package vo;

public class GoodsVO {
	private String JJD_ID;
	
}
