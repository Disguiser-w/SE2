package businesslogic.financebl;

public class CostIncomeReceiptBL {

}
