package businesslogic.managebl;

public class OrganizationBL {
	
}
