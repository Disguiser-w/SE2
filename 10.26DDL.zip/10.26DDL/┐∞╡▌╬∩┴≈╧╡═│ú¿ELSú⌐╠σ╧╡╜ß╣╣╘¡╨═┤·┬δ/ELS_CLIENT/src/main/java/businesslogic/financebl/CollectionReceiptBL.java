package businesslogic.financebl;

public class CollectionReceiptBL {

}
