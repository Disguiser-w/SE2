package businesslogic.financebl;

public class BusinessStatementReceiptBL {

}
