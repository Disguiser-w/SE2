package businesslogic.financebl;

public class PaymentReceiptBL {

}
