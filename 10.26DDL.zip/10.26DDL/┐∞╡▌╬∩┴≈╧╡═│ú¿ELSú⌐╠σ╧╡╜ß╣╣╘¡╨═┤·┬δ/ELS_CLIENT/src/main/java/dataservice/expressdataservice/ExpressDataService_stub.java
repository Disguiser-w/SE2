package dataservice.expressdataservice;

import po.CostBasePO;
import po.ExpressPO;

public class ExpressDataService_stub implements ExpressDataService{

	public CostBasePO getBaseCost() {
		// TODO Auto-generated method stub
		System.out.println("Show CostBasePO!");
		return null;
	}

	public boolean chargeCollection(ExpressPO po) {
		// TODO Auto-generated method stub
		System.out.println("ChargeCollection successfully!");
		return false;
	}

	public ExpressPO getExpressInfos() {
		// TODO Auto-generated method stub
		System.out.println("Show ExpressPO!");
		return null;
	}

}
